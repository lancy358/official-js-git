<template>
    <div>
        <h1>404</h1>
        <h2>没有你要的页面</h2>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>