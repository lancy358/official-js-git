// import {productAPI} from '../api/api'
const axios = require("axios");
const state ={
    imgPath:''
}
const mutations={
  
}
const actions ={
 
}
const getters={
 
}
export default {
    state,
    mutations,
    actions,
    getters
  }